// 自检：用假 ctx 验证插件的拦截与放行
import assert from 'assert';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { plugin_init, plugin_config_schema } from './index.mjs';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bsplugin-'));
const cfg = path.join(dir, 'config.json');
const setOn = (on) => fs.writeFileSync(cfg, JSON.stringify({ enable: on }));

// 假核心：MsgApi 只有最底层 sendMsg，其余由插件包装
const calls = [];
const MsgApi = {
  sendMsg: (...a) => { calls.push('sendMsg'); return Promise.resolve('ok'); },
  forwardMsg: (...a) => { calls.push('forwardMsg'); return Promise.resolve('ok'); },
  multiForwardMsg: (...a) => { calls.push('multiForwardMsg'); return Promise.resolve('ok'); }
};
const sendAction = { handle: () => { calls.push('handle'); return 'ok'; }, websocketHandle: () => 'ok' };
const getInfoAction = { handle: () => { calls.push('getInfo'); return 'ok'; } };
const actions = { get: (n) => (n === 'send_poke' ? sendAction : n === 'get_login_info' ? getInfoAction : undefined) };

const logs = [];
plugin_init({
  core: { apis: { MsgApi } },
  actions,
  configPath: cfg,
  logger: { log: (m) => logs.push(m), info() {}, warn() {}, error() {}, debug() {} }
});
assert.strictEqual(plugin_config_schema[0].key, 'enable');

// 关闭：全部放行
setOn(false);
await MsgApi.sendMsg({}, []);
MsgApi.forwardMsg({}, {}, []);
MsgApi.multiForwardMsg({}, {}, []);
assert.strictEqual(actions.get('send_poke').handle(), 'ok');

// 开启：MsgApi 与 send_* action 全部拦截
setOn(true);
assert.throws(() => MsgApi.sendMsg({}, []), /已被拦截/);
assert.throws(() => MsgApi.forwardMsg({}, {}, []), /已被拦截/);
assert.throws(() => MsgApi.multiForwardMsg({}, {}, []), /已被拦截/);
assert.throws(() => actions.get('send_poke').handle(), /已被拦截/);

// 非发送 action 不受影响
assert.strictEqual(actions.get('get_login_info').handle(), 'ok', '查询类 action 必须放行');

// 关闭后立即恢复，无需重启
setOn(false);
assert.strictEqual(await MsgApi.sendMsg({}, []), 'ok');

fs.rmSync(dir, { recursive: true, force: true });
console.log('plugin self-check ok: 关=全放行 / 开=消息+转发+send_* 全拦 / 查询放行 / 改回即生效');
