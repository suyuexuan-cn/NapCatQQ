import fs from 'fs';

const state = { cfg: null };
const HOOK = Symbol.for('napcat-plugin-block-send');

/** 开关：插件配置 enable 为 true 时拦截（每次读文件，改完立即生效） */
function blocked () {
  try {
    return !!JSON.parse(fs.readFileSync(state.cfg, 'utf-8')).enable;
  } catch {
    return false;
  }
}

/** 包住一个方法：开关开启时抛错，调用方拿到失败响应 */
function guard (obj, name) {
  const original = obj[name];
  if (typeof original !== 'function' || original[HOOK]) return;
  const wrapped = function (...args) {
    if (blocked()) throw new Error('出站消息已被拦截（出站拦截插件已开启）');
    return original.apply(this, args);
  };
  wrapped[HOOK] = true;
  obj[name] = wrapped;
}

export const plugin_init = (ctx) => {
  state.cfg = ctx.configPath;

  // 1) 正常消息与转发的唯一出口
  for (const name of ['sendMsg', 'forwardMsg', 'multiForwardMsg']) guard(ctx.core?.apis?.MsgApi ?? {}, name);

  // 2) 不走 MsgApi 的发送类 action（戳一戳/点赞/AI语音等），按名字前缀兜住
  const actions = ctx.actions;
  const get = actions.get.bind(actions);
  actions.get = (name) => {
    const action = get(name);
    if (action && typeof name === 'string' && name.startsWith('send_'))
      for (const m of ['handle', 'websocketHandle']) guard(action, m);
    return action;
  };

  ctx.logger.log('出站拦截插件已加载，当前：' + (blocked() ? '拦截中' : '放行'));
};

export const plugin_config_schema = [
  {
    key: 'enable',
    type: 'boolean',
    label: '拦截所有出站消息',
    description: '开启后群聊/私聊/临时会话/转发全部发不出去，接收不受影响',
    default: false
  }
];
