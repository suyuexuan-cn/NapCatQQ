# 出站拦截插件

开启后拦截本账号所有对外发送的消息（群聊、私聊、临时会话、转发、戳一戳等），接收完全不受影响。

## 开关在哪

**方式一：WebUI 插件配置**（推荐）
NapCat WebUI → 插件 → 「出站拦截」→ 勾选「拦截所有出站消息」→ 保存。

**方式二：直接改配置文件**
`napcat/config/plugins/napcat-plugin-block-send/config.json`：

```json
{ "enable": true }
```

两种方式都**立即生效**，不用重启（每次发送时现读配置）。

## 装了哪些文件

```
napcat/plugins/napcat-plugin-block-send/
├── package.json     插件清单
├── index.mjs        插件入口（plugin_init + plugin_config_schema）
└── selftest.mjs     自检脚本
napcat/config/plugins/napcat-plugin-block-send/config.json   开关
napcat/config/plugins.json                                   已把插件设为启用
```

## 拦截点

| 位置 | 覆盖 |
|---|---|
| `MsgApi.sendMsg` / `forwardMsg` / `multiForwardMsg` | 群聊、私聊、临时会话、单条转发、合并转发 |
| 所有 `send_*` action 的 `handle` / `websocketHandle` | `send_poke`、`send_like`、`send_group_ai_record` 等不走 MsgApi 的发送 |

插件通过 `ctx.core.apis.MsgApi` 和 `ctx.actions.get` 打包装来实现，不改 NapCat 源码。

## 对 NapCat 的唯一一处改动

`napcat.mjs` 里的插件白名单（`OFFICIAL_PLUGIN_IDS`）加了一行：

```js
"napcat-plugin-block-send"
```

不改这一行，加载器会以「not in official plugin whitelist」拒绝加载本插件。原文件备份在 `napcat.mjs.bak`。

## 验证

```powershell
cd E:\QQBOT\NapCat.Shell.Windows.Node\napcat\plugins\napcat-plugin-block-send
node selftest.mjs
```

实机：开启开关 → 发群/私聊消息应收到失败响应且 QQ 里看不到；关闭 → 正常发出。
